# LIFELINE-second-year-group-project-CS-Group-38-
This repository is to manage the work for CS group 38 project "LIFELINE" 

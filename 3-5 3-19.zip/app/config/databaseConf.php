<?php

define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'life_line');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
<?php 
    require 'config/DatabaseConf.php';
    require 'libs/App.php';
    require 'libs/Controller.php';
    require 'libs/Database.php';
    require 'libs/Model.php';
    require 'libs/View.php';

    $app = new App();
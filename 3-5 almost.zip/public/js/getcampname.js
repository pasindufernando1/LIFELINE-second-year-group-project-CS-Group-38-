window.addEventListener("load", function () {
    // your code here
});